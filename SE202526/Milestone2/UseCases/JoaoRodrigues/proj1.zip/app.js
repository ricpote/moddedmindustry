//@author João Rodrigues n67912
//@author Tomás Silva n68725

import { loadShadersFromURLS, buildProgramFromSources, setupWebGL } from "../../libs/utils.js";

let canvas;
let gl;
let program;
let vao;

const keysContent = document.getElementById("keysContent");
const familyDisplay = document.getElementById("family");
const coefDisplay = document.getElementById("coefs");
const tMinDisplay = document.getElementById("t0");
const tMaxDisplay = document.getElementById("t1");
const pointsDisplay = document.getElementById("points");

const animationSpeed = 0.25;
const maxPoints = 60000;
const minPoints = 500;

let family = 1;
let points = 60000;

let tMinMax = {
    1: [0.0, 2 * Math.PI],
    2: [0.0, 2 * Math.PI],
    3: [0.0, 10 * Math.PI],
    4: [0.0, 10],
    5: [0.0, 10],
    6: [0.0, 2 * Math.PI]
};

let coefs = {
    1: [1.0, 1.0, 0.0],
    2: [1.0, 17.0, 0.0],
    3: [1.0, 8.6, 0.0],
    4: [7.6, 5.1, 0.0],
    5: [1.0, 4.0, 0.0],
    6: [4.0, 1.0, 0.0]
};
//pos in array (0=a;1=b;2=c)
let curCoef = 0;

let isAnimating = false;
let isPoints = true;
let isDragging = false;

let prevXY = [0.0, 0.0];
let curXY = [0.0, 0.0];
let zoom = 1.0;

//color varies between 0 & 10 (position in array)
let color = 0;

function resize(target) {
    // Aquire the new window dimensions
    const width = target.innerWidth;
    const height = target.innerHeight;

    // Set canvas size to occupy the entire window
    canvas.width = width;
    canvas.height = height;

    // Set the WebGL viewport to fill the canvas completely
    gl.viewport(0, 0, width, height);
}

//Sends the display info that varies to html
function updateInfo() {
    let text = "[";
    text += coefs[family][0].toFixed(2);
    text += ", ";
    text += coefs[family][1].toFixed(2);
    if (family == 1) {
        text += ", ";
        text += coefs[family][2].toFixed(2);
    }
    text += "]";
    coefDisplay.textContent = text;
    familyDisplay.textContent = family;
    tMinDisplay.textContent = tMinMax[family][0].toFixed(2);
    tMaxDisplay.textContent = tMinMax[family][1].toFixed(2);
    pointsDisplay.textContent = points;
}

//Resets the coefficients, tMax, num of points and color (operation 'r')
function reset() {
    coefs = {
        1: [1.0, 1.0, 0.0],
        2: [1.0, 17.0, 0.0],
        3: [1.0, 8.6, 0.0],
        4: [7.6, 5.1, 0.0],
        5: [1.0, 4.0, 0.0],
        6: [4.0, 1.0, 0.0]
    };
    tMinMax = {
        1: [0.0, 2 * Math.PI],
        2: [0.0, 2 * Math.PI],
        3: [0.0, 10 * Math.PI],
        4: [0.0, 10],
        5: [0.0, 10],
        6: [0.0, 2 * Math.PI]
    };
    points = 60000;
    color = 0;
}

function setup(shaders) {
    canvas = document.getElementById("gl-canvas");
    gl = setupWebGL(canvas, { alpha: true, preserveDrawingBuffer: false });

    // Create WebGL programs
    program = buildProgramFromSources(gl, shaders["shader1.vert"], shaders["shader1.frag"]);

    const a_index = new Uint32Array(maxPoints);
    for (let i = 0; i < maxPoints; i++) {
        a_index[i] = i;
    }

    const aBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, aBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, a_index, gl.STATIC_DRAW);

    vao = gl.createVertexArray();
    gl.bindVertexArray(vao);

    const a_position = gl.getAttribLocation(program, "a_position");
    gl.vertexAttribIPointer(a_position, 1, gl.UNSIGNED_INT, false, 0, 0);
    gl.enableVertexAttribArray(a_position);


    updateInfo();
    resize(window);

    // Handle resize events 
    window.addEventListener("resize", (event) => {
        resize(event.target);
    })

    window.addEventListener("keydown", (event) => {
        const key = event.key;
        if (key >= '1' && key <= '6') {
            family = parseInt(key);
            curCoef = 0;
            reset();
        }
        switch (key) {
            case "h":
                keysContent.classList.toggle("hidden");
                break;
            case "ArrowUp":
                coefs[family][curCoef] += 0.01;
                if (isAnimating)
                    isAnimating = !isAnimating;
                break;
            case "ArrowDown":
                coefs[family][curCoef] -= 0.01;
                if (isAnimating)
                    isAnimating = !isAnimating;
                break;
            case "ArrowLeft":
                if (curCoef == 0 && family == 1)
                    curCoef = 2;
                else if (curCoef == 0 && family != 1)
                    curCoef = 1;
                else
                    curCoef--;
                break;
            case "ArrowRight":
                if (curCoef == 2 && family == 1)
                    curCoef = 0;
                else if (curCoef == 1 && family != 1)
                    curCoef = 0;
                else
                    curCoef++;
                break;
            case "PageUp":
                tMinMax[family][1] += 0.01;
                break;
            case "PageDown":
                if (tMinMax[family][1] >= 0.01)
                    tMinMax[family][1] -= 0.01;
                break;
            case " ":
                isAnimating = !isAnimating;
                break;
            case "r":
                reset();
                break;
            case "p":
                isPoints = !isPoints;
                break;
            case "+":
                if (points < maxPoints)
                    points += 500
                break;
            case "-":
                if (points > minPoints)
                    points -= 500
                break;
        }
        updateInfo();
    })

    window.addEventListener("wheel", (event) => {
        const rect = canvas.getBoundingClientRect();
        const mouseX = ((event.clientX - rect.left) / canvas.width) * 2 - 1;
        const mouseY = -(((event.clientY - rect.top) / canvas.height) * 2 - 1);

        const oldZoom = zoom;
        if (event.deltaY < 0) {
            zoom *= 1.1;
        } else {
            zoom /= 1.1;
        }

        curXY[0] = mouseX - (mouseX - curXY[0]) * (zoom / oldZoom);
        curXY[1] = mouseY - (mouseY - curXY[1]) * (zoom / oldZoom);
    })

    window.addEventListener("mousedown", (event) => {
        isDragging = true;
        prevXY[0] = event.clientX;
        prevXY[1] = event.clientY;
    });

    window.addEventListener("mouseup", (event) => {
        isDragging = false;
    });

    window.addEventListener("mousemove", (event) => {
        if (!isDragging) return;

        curXY[0] += (event.clientX - prevXY[0]) / canvas.width * 2.0 * (canvas.width / canvas.height);
        curXY[1] -= (event.clientY - prevXY[1]) / canvas.height * 2.0;

        prevXY[0] = event.clientX;
        prevXY[1] = event.clientY;

    });



    keysContent.querySelectorAll(".colorBox").forEach(box => {
        box.addEventListener("click", () => {
            color = parseInt(box.dataset.index);

        });
    });

    gl.clearColor(0.0, 0.0, 0.0, 1.0);
    window.requestAnimationFrame(animate);
}

function animate(timestamp) {
    window.requestAnimationFrame(animate);

    if (isAnimating) {
        coefs[family][curCoef] += 0.01 * animationSpeed;
        updateInfo();
    }

    gl.clear(gl.COLOR_BUFFER_BIT);

    gl.useProgram(program);

    gl.uniform1i(gl.getUniformLocation(program, "family"), family);
    gl.uniform1f(gl.getUniformLocation(program, "nPoints"), points);
    gl.uniform1f(gl.getUniformLocation(program, "aspRatio"), canvas.width / canvas.height);

    gl.uniform2f(gl.getUniformLocation(program, "t0t1"), tMinMax[family][0], tMinMax[family][1]);
    gl.uniform3f(gl.getUniformLocation(program, "abc"), coefs[family][0], coefs[family][1], coefs[family][2]);

    gl.uniform2f(gl.getUniformLocation(program, "moveXY"), curXY[0], curXY[1]);
    gl.uniform1f(gl.getUniformLocation(program, "zoom"), zoom);

    gl.uniform1i(gl.getUniformLocation(program, "color"), color);
    gl.uniform1f(gl.getUniformLocation(program, "time"), performance.now() / 250);

    if (isPoints)
        gl.drawArrays(gl.POINTS, 0, points);
    else
        gl.drawArrays(gl.LINES, 0, points);

    // Some drawing code...
    gl.useProgram(null);
}


loadShadersFromURLS(["shader1.vert", "shader1.frag"]).then(shaders => setup(shaders));
