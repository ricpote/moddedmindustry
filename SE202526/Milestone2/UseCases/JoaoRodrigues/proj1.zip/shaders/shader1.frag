#version 300 es

//@author João Rodrigues n67912
//@author Tomás Silva n68725

precision mediump float;

in vec4 v_color;
out vec4 frag_color;

void main() {
    frag_color = v_color;

}