#version 300 es

//@author João Rodrigues n67912
//@author Tomás Silva n68725

uniform int family;
uniform float nPoints;
uniform float aspRatio;
in uint a_position;

//tMin (pos 0) & tMax (pos 1)
uniform vec2 t0t1;

//coefficients (a pos 0, b pos 1, c pos 2)
uniform vec3 abc;

//drag moviment (x pos 0, y pos 1)
uniform vec2 moveXY;
//wheel movement
uniform float zoom;

//current color (pos in array colors)
uniform int color;
vec4 colors[11];

uniform float time;

out vec4 v_color;

void main() {

    float t = t0t1[0] + float(a_position) * ((t0t1[1] - t0t1[0]) / (nPoints - 1.0f));

    //rgb
    colors[0] = vec4(0.5f + 0.5f * cos(t), 0.5f + 0.5f * cos(t + 2.0f * 3.14f / 3.0f), 0.5f + 0.5f * cos(t + 4.0f * 3.14f / 3.0f), 1.0f);
    //rgb changing
    colors[1] = vec4(0.5f + 0.5f * cos(t + time), 0.5f + 0.5f * cos(t + 2.0f * 3.14f / 3.0f + time), 0.5f + 0.5f * cos(t + 4.0f * 3.14f / 3.0f + time), 1.0f);
    colors[2] = vec4(1.0f, 0.0f, 0.0f, 1.0f); //red
    colors[3] = vec4(0.0f, 1.0f, 0.0f, 1.0f); //green
    colors[4] = vec4(0.0f, 0.0f, 1.0f, 1.0f); //blue
    colors[5] = vec4(1.0f, 1.0f, 0.0f, 1.0f); //yellow
    colors[6] = vec4(1.0f, 0.5f, 0.0f, 1.0f); //orange
    colors[7] = vec4(0.5f, 0.0f, 0.5f, 1.0f); //purple
    colors[8] = vec4(1.0f, 0.0f, 0.5f, 1.0f); //pink
    colors[9] = vec4(1.0f, 1.0f, 1.0f, 1.0f); //white
    colors[10] = vec4(0.15f, 0.15f, 0.15f, 1.0f); //black

    v_color = colors[color];

    float x;
    float y;

    switch(family) {
        case 1:
            x = (cos(abc[0] * t) + cos(abc[1] * t) / 2.0f + sin(abc[2] * t) / 3.0f);
            y = (sin(abc[0] * t) + sin(abc[1] * t) / 2.0f + cos(abc[2] * t) / 3.0f);
            break;

        case 2:
            x = 2.0f * (cos(abc[0] * t) + pow(cos(abc[1] * t), 3.0f));
            y = 2.0f * (sin(abc[0] * t) + pow(sin(abc[1] * t), 3.0f));
            break;

        case 3:
            x = (cos(abc[0] * t) * sin(sin(abc[0] * t)));
            y = (sin(abc[0] * t) * cos(cos(abc[1] * t)));
            break;

        case 4:
            x = cos(abc[0] * t) * cos(abc[1] * t);
            y = sin(cos(abc[0] * t));
            break;

        case 5:
            x = sin(abc[0] * t) * (exp(cos(abc[0] * t)) - 2.0f * cos(abc[1] * t));
            y = cos(abc[0] * t) * (exp(cos(abc[0] * t)) - 2.0f * cos(abc[1] * t));
            break;

        case 6:
            x = (abc[0] - abc[1]) * cos(abc[1] * t) + cos(abc[0] * t - abc[1] * t);
            y = (abc[0] - abc[1]) * sin(abc[1] * t) - sin(abc[0] * t - abc[1] * t);
            break;

    }

    gl_Position = vec4((x * zoom + moveXY[0]) / aspRatio, y * zoom + moveXY[1], 0.0f, 1.0f);
    gl_PointSize = 5.0f;

}
